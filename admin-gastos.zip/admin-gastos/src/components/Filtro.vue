<script setup>

</script>

<template>
    <div>
        <h2>Filtros</h2>
    </div>
</template>



<style scoped>
    h2 {
        color: blue;
    }
</style>